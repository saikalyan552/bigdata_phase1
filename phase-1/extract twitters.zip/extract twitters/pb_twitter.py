from tweepy import Stream
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler

consumer_key = '70CY5GcCR8oceTIOWDy3v5NdY'
consumer_secret = 'r2fCSdMrWEm0oeaRGd72WM6FNM56Y2JpZHnjn5zGjju8luBCBe'
access_token = '752421522367582208-3EZOpFZ7WFbzPrkqaDimljfWEX1iouI'
access_secret = 'dct0XRd8B9tW0ZXMxMISXlTvllDZjei8itt5ipit0yMl0'
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

class MyListener(StreamListener):

    def on_data(self, data):
        try:
            with open('sample.json', 'a') as f:
                f.write(data.encode('utf-8'))
                return True
        except BaseException as e:
            print("Error on_data: %s" % str(e))
        return True

    def on_error(self, status):
        print(status)
        return True


twitter_stream = Stream(auth, MyListener())
twitter_stream.filter(track=['India'])
i
